import React, { useState, useEffect, useRef } from 'react';
import '../App.css';

const ClientReviews = () => {
    // Text Reviews Data
    const textReviews = [
        {
            id: 1,
            name: "Sarah Johnson",
            role: "Marketing Director, Techvision Corp",
            rating: 5,
            text: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        },
        {
            id: 2,
            name: "Michael Chen",
            role: "CEO, StartUp Inc",
            rating: 5,
            text: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        },
        {
            id: 3,
            name: "Emily Davis",
            role: "Brand Manager, Creative Solutions",
            rating: 5,
            text: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        },
        {
            id: 4,
            name: "David Wilson",
            role: "Product Lead, InnovateX",
            rating: 5,
            text: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        }
    ];

    // Video Reviews Data (Using placeholders as requested)
    // Video Reviews Data
    const videoReviews = [
        {
            id: 1,
            title: "Emily Davis",
            subtitle: "CEO, TechFlow",
            rating: 5,
            description: "Octoink Studio transformed our brand identity completely. The team understood our vision perfectly and delivered a design system that is both scalable and stunning. Highly recommended!",
            videoUrl: "https://www.pexels.com/download/video/7467694/",
            thumbnail: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        },
        {
            id: 2,
            title: "Mark Thompson",
            subtitle: "Founder, GreenEarth",
            rating: 5,
            description: "The video editing services were exceptional. They turned our raw footage into a compelling story that resonated with our audience. The turnaround time was incredibly fast too.",
            videoUrl: "https://www.pexels.com/download/video/10503714/",
            thumbnail: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        },
        {
            id: 3,
            title: "Sarah Jenkins",
            subtitle: "Marketing Head, StyleUp",
            rating: 5,
            description: "We needed a complete website overhaul, and Octoink delivered beyond expectations. The new site is faster, looks amazing, and has significantly improved our conversion rates.",
            videoUrl: "https://www.pexels.com/download/video/3797445/",
            thumbnail: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        },
        {
            id: 4,
            title: "David Chen",
            subtitle: "Director, FutureTech",
            rating: 5,
            description: "Their 3D modeling skills are top-notch. The product visualizations they created for our launch were hyper-realistic and played a huge role in our pre-order success.",
            videoUrl: "https://www.pexels.com/download/video/6344467/",
            thumbnail: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        },
        {
            id: 5,
            title: "Jessica Lee",
            subtitle: "Owner, CreativeSpace",
            rating: 5,
            description: "A pleasure to work with. Professional, creative, and responsive. They handled our social media graphics for the entire year, maintaining a consistent and high-quality look.",
            videoUrl: "https://www.pexels.com/download/video/8369977/",
            thumbnail: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s"
        }
    ];

    // Text Carousel State
    const [currentTextIndex, setCurrentTextIndex] = useState(0);
    const [isTextPaused, setIsTextPaused] = useState(false);
    const textIntervalRef = useRef(null);

    // Text Carousel Logic
    useEffect(() => {
        if (!isTextPaused) {
            textIntervalRef.current = setInterval(() => {
                setCurrentTextIndex((prevIndex) =>
                    prevIndex === textReviews.length - 1 ? 0 : prevIndex + 1
                );
            }, 3000); // Change slide every 3 seconds
        }

        return () => {
            if (textIntervalRef.current) clearInterval(textIntervalRef.current);
        };
    }, [isTextPaused, textReviews.length]);

    const handleTextHover = (isHovering) => {
        setIsTextPaused(isHovering);
    };


    // Video Carousel State
    const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
    const videoRefs = useRef([]);

    // Video Carousel Logic - simple manual navigation for now, or auto?
    // User asked for 10 videos slide. Assuming manual navigation or auto? 
    // "reviwe is audo matic slide" was for text reviews.
    // "the secont image is a the clint reviwe videos the videos is auto matic play" -> 
    // This implies the video *content* plays automatically, not necessarily the carousel slides.
    // But usually carousels are manual or auto. Let's make it manual with dots for 10 items.

    const handleVideoChange = (index) => {
        setCurrentVideoIndex(index);
    };

    const handleVideoEnd = () => {
        setCurrentVideoIndex((prevIndex) =>
            prevIndex === videoReviews.length - 1 ? 0 : prevIndex + 1
        );
    };

    // Toggle Audio Logic
    const toggleAudio = (videoElement) => {
        if (videoElement) {
            videoElement.muted = !videoElement.muted;
        }
    };

    // Helper to render stars
    const renderStars = (rating) => {
        return "★".repeat(rating);
    };

    return (
        <section className="client-reviews-section">
            <div className="section-header">
                <span className="section-label-small">TESTIMONIALS</span>
                <h2>What our Clients<br />Say About Us</h2>
                <p className="section-subheader">Don't just take our word for it. Here's what businesses say about working with us.</p>
            </div>

            {/* Text Reviews Carousel */}
            <div className="reviews-carousel-container"
                onMouseEnter={() => handleTextHover(true)}
                onMouseLeave={() => handleTextHover(false)}>

                <div className="reviews-track" style={{ transform: `translateX(-${currentTextIndex * 100}%)` }}>
                    {textReviews.map((review) => (
                        <div className="review-card" key={review.id}>
                            <div className="review-stars">{renderStars(review.rating)}</div>
                            <p className="review-text">{review.text}</p>
                            <div className="review-author">
                                <div className="author-image">
                                    <img src={review.image} alt={review.name} />
                                </div>
                                <div className="author-info">
                                    <h4>{review.name}</h4>
                                    <p>{review.role}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Dots for Text Carousel */}
                <div className="carousel-dots">
                    {textReviews.map((_, index) => (
                        <span
                            key={index}
                            className={`dot ${index === currentTextIndex ? 'active' : ''}`}
                            onClick={() => setCurrentTextIndex(index)}
                        ></span>
                    ))}
                </div>
            </div>

            {/* Video Reviews Section */}
            <div className="video-reviews-container">
                <div className="video-slide">
                    <div className="video-content-wrapper animate-fade-in-up" key={currentVideoIndex}>
                        {/* Video Side */}
                        <div className="video-wrapper">
                            <video
                                key={currentVideoIndex} // Add key to force re-render on change
                                src={videoReviews[currentVideoIndex].videoUrl}
                                autoPlay
                                muted
                                playsInline
                                onEnded={handleVideoEnd} // Auto advance logic
                                ref={el => videoRefs.current[currentVideoIndex] = el}
                                className="client-video"
                            />
                            <div className="video-overlay">
                                <button
                                    className="audio-toggle-btn"
                                    onClick={(e) => {
                                        e.preventDefault();
                                        toggleAudio(videoRefs.current[currentVideoIndex]);
                                    }}
                                >
                                    🔊/🔇
                                </button>
                            </div>
                        </div>

                        {/* Content Side */}
                        <div className="video-text-content">
                            <div className="video-author-image">
                                <img src="https://vectorart.ai/images/prompt3.svg" alt="Character" />
                            </div>
                            <h3>{videoReviews[currentVideoIndex].title}</h3>
                            <p className="video-subtitle">{videoReviews[currentVideoIndex].subtitle}</p>
                            <div className="video-stars">{renderStars(videoReviews[currentVideoIndex].rating)} <span>5 Star</span></div>
                            <p className="video-description">
                                {videoReviews[currentVideoIndex].description}
                            </p>
                        </div>
                    </div>
                </div>


                {/* Navigation for Video Carousel */}
                <div className="video-carousel-dots">
                    {videoReviews.map((_, index) => (
                        <span
                            key={index}
                            className={`video-dot ${index === currentVideoIndex ? 'active' : ''}`}
                            onClick={() => handleVideoChange(index)}
                        ></span>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default ClientReviews;
