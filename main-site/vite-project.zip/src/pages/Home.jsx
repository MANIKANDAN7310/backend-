import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import '../App.css';
import ClientReviews from '../components/ClientReviews';
import Contact from '../components/Contact';
import Footer from '../components/Footer';
import LanguageSelector from '../components/LanguageSelector';

function Home() {
    const testimonials = [
        {
            id: 1,
            name: "John Doe",
            image: "/client1.jpg",
            text: "Octoink transformed our branding with their incredible vector art. Highly recommended!   "
        },
        {
            id: 2,
            name: "Jane Smith",
            image: "/client1.jpg",
            text: "The enamel pins we ordered for our event were a hit! Exceptional quality and detail."
        },
        {
            id: 3,
            name: "Robert Brown",
            image: "/client1.jpg",
            text: "Professional, timely, and creative. Their embroidery designs exceeded our expectations."
        },
        {
            id: 4,
            name: "Emily Davis",
            image: "/client1.jpg",
            text: "Fantastic service! They helped us refine our logo and brand identity perfectly."
        },
        {
            id: 5,
            name: "Michael Wilson",
            image: "/client1.jpg",
            text: "Great experience working with the team. The production quality is top-notch."
        },
        {
            id: 6,
            name: "Sarah Johnson",
            image: "/client1.jpg",
            text: "I love the custom patches! They look amazing on our uniforms. Will order again."
        },
        {
            id: 7,
            name: "David Lee",
            image: "/client1.jpg",
            text: "Quick turnaround and excellent communication throughout the design process."
        },
        {
            id: 8,
            name: "Jessica White",
            image: "/client1.jpg",
            text: "The attention to detail in their work is unmatched. A true partner for our brand."
        },
        {
            id: 9,
            name: "Chris Green",
            image: "/client1.jpg",
            text: "Highly skilled designers who truly understand client needs. 5 stars!"
        },
        {
            id: 10,
            name: "Amanda Clark",
            image: "/client1.jpg",
            text: "From concept to delivery, everything was seamless. Thank you Octoink!"
        }
    ];

    const [currentIndex, setCurrentIndex] = useState(0);
    const [itemsPerPage, setItemsPerPage] = useState(3);
    const [isPaused, setIsPaused] = useState(false);

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < 768) {
                setItemsPerPage(1);
            } else {
                setItemsPerPage(3);
            }
        };

        handleResize(); // Initial check
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    useEffect(() => {
        if (isPaused) return;

        const interval = setInterval(() => {
            nextSlide();
        }, 3000);

        return () => clearInterval(interval);
    }, [currentIndex, isPaused, itemsPerPage]);

    const nextSlide = () => {
        setCurrentIndex((prevIndex) =>
            (prevIndex + 1) % (testimonials.length - itemsPerPage + 1)
        );
        // Reset to start loop smoothly or bounce back? 
        // Simple finite scroll loop:
        if (currentIndex >= testimonials.length - itemsPerPage) {
            setCurrentIndex(0);
        } else {
            setCurrentIndex(currentIndex + 1);
        }
    };

    const goToSlide = (index) => {
        setCurrentIndex(index);
    };



    const [heroIndex, setHeroIndex] = useState(0);
    const [activeCategory, setActiveCategory] = useState("All");

    const categories = [
        "All",
        "Embroidery Design",
        "Enamel Pin Collection",
        "Medals Design",
        "Coins Design",
        "Vector Art and Poster"
    ];

    const portfolioItems = [
        { id: 1, category: "Embroidery Design", image: "./src/assets/emb1.jpg", title: "Custom Embroidery" },
        { id: 2, category: "Enamel Pin Collection", image: "./src/assets/91SPgUm6UEL._AC_UY1100_.jpg", title: "Custom Pins" },
        { id: 3, category: "Medals Design", image: "./src/assets/die-cast-medals.png", title: "Custom Medals" },
        { id: 4, category: "Coins Design", image: "./src/assets/coinimage1.jpg", title: "Custom Coins" },
        { id: 5, category: "Vector Art and Poster", image: "./src/assets/vector3.jpg", title: "Vector Illustration" },
        { id: 6, category: "Embroidery Design", image: "./src/assets/applique.jpg", title: "applique" },
        { id: 7, category: "Enamel Pin Collection", image: "./src/assets/pin2.jpg", title: "Custom Pins" },
        { id: 8, category: "Enamel Pin Collection", image: "./src/assets/soft-vs-hard.jpg", title: "Soft vs Hard" },
        { id: 9, category: "Vector Art and Poster", image: "./src/assets/vector2.jpg", title: "Vector Art" },
        { id: 10, category: "Medals Design", image: "./src/assets/1754917181858.jpg", title: "Running Medals" },
        { id: 11, category: "Medals Design", image: "./src/assets/Ornanment2.jpg", title: "Custom Ornamen" },
        { id: 12, category: "Coins Design", image: "./src/assets/coinimage2.jpg ", title: "Commemorative Coin" },
        { id: 13, category: "Coins Design", image: "./src/assets/coinimage3.jpg ", title: "Commemorative Coin" },
        { id: 14, category: "Embroidery Design", image: "./src/assets/emb2.jpg", title: " Anime Embroidery" },
        { id: 15, category: "Vector Art and Poster", image: "./src/assets/poster.jpg", title: "Poster Design" },
    ];

    const filteredPortfolio = activeCategory === "All"
        ? portfolioItems
        : portfolioItems.filter(item => item.category === activeCategory);

    const heroImages = [
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s",
        "https://images-cdn.ubuy.co.in/63a34c27da9b6328f52b7822-benbo-9-pieces-cute-enamel-pins-set.jpg",
        "https://cpimg.tistatic.com/09614390/b/4/Custom-Enamel-Pin.jpg",
        "https://i.ytimg.com/vi/yj2H4WbBo50/hqdefault.jpg",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnL5036NLcZxlPCZhjPt-VMPKvgBVUwBImNQ&s",
        "https://m.media-amazon.com/images/I/71DkysiiziL._AC_UF894,1000_QL80_.jpg",
        "https://dippedindoodles.in/cdn/shop/collections/1.jpg?v=1686382559",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwhGCCKhNF2OQSeM3i_HEHkcLVvXI4SDG_Ew&s",
        "https://vectorart.ai/images/prompt3.svg",
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0CsSgYaStrKjomUXblY5P8ndO5kYzDXdDcQ&s"
    ];

    useEffect(() => {
        const interval = setInterval(() => {
            setHeroIndex((prevIndex) => (prevIndex + 1) % heroImages.length);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="main-bg">
            <header className="header">
                <div className="logo"> <img src="../src/assets/logo.png" alt="Logo" width="50px" height="40px" />Octoink Studio</div>
                <nav>
                    <a href="#services">Services</a>
                    <a href="#portfolio">Portfolio</a>
                    <a href="#process">Process</a>
                    <Link to="/store">Store</Link>
                    <a href="#contact" className="btn-quote-nav">Get a Quote</a>
                    <LanguageSelector />
                </nav>
            </header>

            <section className="hero">
                <div className="hero-content">
                    <h1>Transform Your Brand with Stunning Custom Designs</h1>
                    <p>
                        Expert enamel pins, vector art, and embroidery design that elevate your operation’s branding. Professional quality, unique visual style, delivered on time.
                    </p>
                    <div className="hero-buttons">
                        <a href="#services"><button>Start Your Project</button></a>
                        <a href="#portfolio"><button className="secondary">View Our Work</button></a>


                    </div>
                    <div className="hero-stats">
                        <span>200+ Projects Done</span>
                        <span>180+ Happy Clients</span>
                        <span>5 Star Rated Service</span>
                    </div>
                </div>
                <div className="hero-image">
                    {heroImages.map((img, index) => (
                        <img
                            key={index}
                            src={img}
                            alt={`Slide ${index + 1}`}
                            className={`hero-slide ${index === heroIndex ? 'active' : ''}`}
                        />
                    ))}
                </div>
            </section>

            <section className="process" id="process">
                <span className="section-label">PROCESS</span>
                <h2>Simple Process, Outstanding Results</h2>
                <p className="process-description">From initial concept to final delivery, we make the entire process seamless and transparent</p>
                <div className="steps">
                    <div className="step">
                        <div className="step-badge">01</div>
                        <div className="step-icon">
                            <span>💬</span>
                        </div>
                        <h3>Consultation</h3>
                        <p>We discuss your vision, brand requirements, and project goals in detail.</p>
                    </div>
                    <div className="step">
                        <div className="step-badge">02</div>
                        <div className="step-icon">
                            <span>🎨</span>
                        </div>
                        <h3>Design & Revision</h3>
                        <p>Our team creates initial concepts and refines them based on your feedback.</p>
                    </div>
                    <div className="step">
                        <div className="step-badge">03</div>
                        <div className="step-icon">
                            <span>✅</span>
                        </div>
                        <h3>Approval</h3>
                        <p>Final Design Review and approval before we move to production.</p>
                    </div>
                    <div className="step">
                        <div className="step-badge">04</div>
                        <div className="step-icon">
                            <span>📦</span>
                        </div>
                        <h3>Production & Delivery</h3>
                        <p>Quality production and timely delivery of your custom designs.</p>
                    </div>
                </div>
            </section>

            <section className="services" id="services">
                <span className="section-label">SERVICES</span>
                <h2>Professional Design Services for Your Business</h2>
                <p className="process-description">We specialize in creating premium custom designs that make your brand stand out. From concept to production, we deliver excellence at every step.</p>
                <div className="service-cards">
                    <div className="service-card">
                        <div className="service-icon">
                            <span>📌</span>
                        </div>
                        <h3>Enamel Pins</h3>
                        <p className="service-desc">Custom enamel pins for corporate branding, promotional campaigns, and employee recognition programs.</p>
                        <ul>
                            <li>Hard & Soft Enamel</li>
                            <li>Coins & Medals</li>
                            <li>Trading Pins</li>
                            <li>Key Chains</li>
                        </ul>
                    </div>
                    <div className="service-card">
                        <div className="service-icon">
                            <span>✒️</span>
                        </div>
                        <h3>Vector Art</h3>
                        <p className="service-desc">Professional vector illustration and graphics perfect for logos, marketing materials, and brand assets.</p>
                        <ul>
                            <li>Logo & branding design</li>
                            <li>Brand identity</li>
                            <li>Scalable vector graphics</li>
                            <li>Custom illustrations</li>
                        </ul>
                    </div>
                    <div className="service-card">
                        <div className="service-icon">
                            <span>🧵</span>
                        </div>
                        <h3>Embroidery Design</h3>
                        <p className="service-desc">High-Quality Embroidery designs for corporate apparel, uniforms, and promotional merchandise.</p>
                        <ul>
                            <li>Embroidery</li>
                            <li>Applique Embroidery</li>
                            <li>Puff Embroidery</li>
                        </ul>
                    </div>
                </div>
            </section>


            <section className="plans">
                <span className="section-label">OUR SUBSCRIPTIONS</span>
                <h2>Pick a plan to start saving</h2>
                <p className="process-description">Start with any plan and save thousands every month </p>
                <div className="plan-cards">
                    <div className="plan-card">
                        <h3>Weekly Plan</h3>
                        <p>$299 <span>$500 per  month</span></p>
                        <Link to="/quote"><button>Choose Subscription</button></Link>
                        <ul>
                            <li>Features</li>
                            <li>15 design per week</li>
                            <li>Priority support</li>
                            <li>Flexible pausing</li>
                        </ul>
                    </div>
                    <div className="plan-card">
                        <h3>Monthly Plan</h3>
                        <p>$1199 <span>$1500 per month</span></p>
                        <Link to="/quote"><button>Choose Subscription</button></Link>
                        <ul>
                            <li>Features</li>
                            <li>Up to 40 designs/month</li>
                            <li>Priority support</li>
                            <li>Flexible pausing</li>
                        </ul>
                    </div>
                    <div className="plan-card">
                        <h3>Budget Plan</h3>
                        <p>$800 <span>$1000 per month</span></p>
                        <Link to="/quote"><button>Choose Subscription</button></Link>
                        <ul>
                            <li>Features</li>
                            <li>25 designs/month</li>
                            <li>Priority support</li>
                            <li>Flexible pausing</li>
                        </ul>
                    </div>
                </div>
            </section>

            <section className="portfolio" id="portfolio">
                <span className="section-label">PORTFOLIO</span>
                <h2>Our Octoink Works, Done for Growing Brands</h2>
                <p className="process-description">Every design tells a story. Explore our curated works where creativity meets strategy.</p>

                <div className="portfolio-filter">
                    {categories.map((cat, index) => (
                        <button
                            key={index}
                            className={`filter-btn ${activeCategory === cat ? 'active' : ''}`}
                            onClick={() => setActiveCategory(cat)}
                        >
                            {cat}
                        </button>
                    ))}
                </div>

                <div className="portfolio-grid">
                    {filteredPortfolio.map((item) => (
                        <div key={item.id} className="portfolio-item animate-fade-in-up">
                            <img src={item.image} alt={item.title} />
                            <div className="portfolio-overlay">
                                <h3>{item.title}</h3>
                                <p>{item.category}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            <ClientReviews />

            <Contact />


            <Footer />
        </div>
    );
}

export default Home;
