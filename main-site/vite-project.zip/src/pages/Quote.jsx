import { useState, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import '../App.css';
import quoteIllustration from '../assets/Untitled-1.png';
import Footer from '../components/Footer';
import LanguageSelector from '../components/LanguageSelector';

function Quote() {

    const location = useLocation();
    const product = location.state?.product;

    const [step, setStep] = useState(1);
    const [showTerms, setShowTerms] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        companyName: '',
        country: '',
        city: '',
        state: '',
        zipCode: '',
        address: ''
    });
    const [termsRead, setTermsRead] = useState(false);
    const modalBodyRef = useRef(null);

    const handleTermsAction = () => {
        if (!termsRead) {
            if (modalBodyRef.current) {
                modalBodyRef.current.scrollTo({
                    top: modalBodyRef.current.scrollHeight,
                    behavior: 'smooth'
                });
                setTermsRead(true);
            }
        } else {
            handleTermsAccept();
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    // Dynamic Data from Product or Default
    const productTitle = product ? product.title : "Production Ready Monthly Plan";
    const productPrice = product ? product.price : 1199;
    const originalPrice = product ? product.originalPrice : 1699;
    const productImage = product ? product.image : quoteIllustration; // Default fallback ref
    const productCategory = product ? product.category : "Monthly Subscription";

    // Discount Calculation
    const discount = originalPrice && originalPrice > productPrice ? originalPrice - productPrice : 0;

    // Close modal when moving to step 3
    const handleTermsAccept = () => {
        setShowTerms(false);
        setStep(3);
    };

    const handleInvestClick = () => {
        // Move to step 2
        setStep(2);
    };

    const handleNextStep = () => {
        // If we're on step 2, show terms or move to payment
        if (step === 2) {
            // Validation
            const { name, companyName, country, city, state, zipCode, address } = formData;
            if (!name || !companyName || !country || !city || !state || !zipCode || !address) {
                alert("Please fill in all required fields.");
                return;
            }
            setShowTerms(true);
        }
    };

    const handlePayment = () => {
        window.open('https://www.paypal.com/', '_blank');
    };

    return (
        <div className="main-bg">
            <header className="header">
                <div className="logo"><Link to="/" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center', gap: '10px' }}><img src="/src/assets/logo.png" alt="Logo" width="50px" height="40px" />Octoink Studio</Link></div>
                <nav>
                    <Link to="/#services">Services</Link>
                    <Link to="/#portfolio">Portfolio</Link>
                    <Link to="/#process">Process</Link>
                    <Link to="/#testimonials">Testimonials</Link>
                    <Link to="/store">Store</Link>
                    <Link to="/#contact" className="btn-quote-nav active">Get a Quote</Link>
                    <LanguageSelector />
                </nav>
            </header>

            <div className="quote-container">
                {/* Stepper */}
                <div className="quote-stepper">
                    <div className={`step-item ${step >= 1 ? 'active' : ''}`}>
                        <span className="step-check">{step > 1 ? '✓' : '✓'}</span>
                        <span>Service Details</span>
                    </div>
                    <div className="step-line"></div>
                    <div className={`step-item ${step >= 2 ? 'active' : ''}`}>
                        <span className={`step-circle ${step >= 2 ? 'active-circle' : 'step-circle-inactive'}`}>{step > 2 ? '✓' : ''}</span>
                        <span>Client Information</span>
                    </div>
                    <div className="step-line"></div>
                    <div className={`step-item ${step >= 3 ? 'active' : ''}`}>
                        <span className={`step-circle ${step >= 3 ? 'active-circle' : 'step-circle-inactive'}`}></span>
                        <span>Payment</span>
                    </div>
                </div>

                {/* Content */}
                <div className="quote-content-box">

                    {step === 1 && (
                        <>
                            <div className="quote-left">
                                <h2>{productTitle}</h2>
                                <div className="quote-illustration">
                                    <div className="illustration-placeholder">
                                        <span style={{ fontSize: '4rem' }}>
                                            <img
                                                src={productImage}
                                                alt={productTitle}
                                                onError={(e) => { e.target.onerror = null; e.target.src = 'https://placehold.co/600x400?text=Product+Image' }}
                                                style={{ maxWidth: '100%', maxHeight: '400px', objectFit: 'contain' }}
                                            />
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="quote-divider"></div>

                            <div className="quote-right">
                                <h2>{productCategory}</h2>
                                <div className="quote-price">
                                    {originalPrice && <span className="original-price">${originalPrice}</span>}
                                    <span className="current-price">${productPrice}</span>
                                </div>
                                <p className="quote-subtitle">High quality {productTitle} designed for your brand.</p>

                                <div className="quote-features">
                                    <h3>Features</h3>
                                    <ul>
                                        <li>Premium Quality Design</li>
                                        <li>Unlimited Revisions</li>
                                        <li>Fast Turnaround Time</li>
                                        <li>High-Resolution Files</li>
                                    </ul>
                                </div>

                                <button className="btn-invest" onClick={handleInvestClick}>Proceed</button>
                            </div>
                        </>
                    )}

                    {step === 2 && (
                        <div className="client-info-step">
                            <div className="client-form-container">
                                <div className="form-group">
                                    <label>Name*</label>
                                    <input type="text" name="name" value={formData.name} onChange={handleInputChange} placeholder="Enter Your First Name" required />
                                </div>
                                <div className="form-group">
                                    <label>Company Name*</label>
                                    <input type="text" name="companyName" value={formData.companyName} onChange={handleInputChange} placeholder="Enter Your Company Name" required />
                                </div>
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>Country*</label>
                                        <input type="text" name="country" value={formData.country} onChange={handleInputChange} placeholder="Enter Your Country Name" required />
                                    </div>
                                    <div className="form-group">
                                        <label>City*</label>
                                        <input type="text" name="city" value={formData.city} onChange={handleInputChange} placeholder="Enter Your City Name" required />
                                    </div>
                                </div>
                                <div className="form-row">
                                    <div className="form-group">
                                        <label>State/Province/Region*</label>
                                        <input type="text" name="state" value={formData.state} onChange={handleInputChange} placeholder="Enter Your State" required />
                                    </div>
                                    <div className="form-group">
                                        <label>Postal Code*</label>
                                        <input type="text" name="zipCode" value={formData.zipCode} onChange={handleInputChange} placeholder="Enter Your Zip Code" required />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <label>Street Address*</label>
                                    <input type="text" name="address" value={formData.address} onChange={handleInputChange} placeholder="(Street address, apartment, suite, unit etc)" className="full-width-input" required />
                                </div>
                            </div>

                            {/* Sidebar or Summary in Step 2 */}
                            <div className="quote-summary-sidebar">
                                <h3>ORDER DETAILS</h3>
                                <div className="summary-row">
                                    <span>Product Price</span>
                                    <span>${originalPrice ?? productPrice}</span>
                                </div>
                                {discount > 0 && (
                                    <div className="summary-row">
                                        <span>Discount</span>
                                        <span>-${discount}</span>
                                    </div>
                                )}
                                <div className="summary-row">
                                    <span>Tax</span>
                                    <span>$0</span>
                                </div>
                                <div className="summary-total">
                                    <span>Total Amount</span>
                                    <span>${productPrice}</span>
                                </div>
                                {discount > 0 && <p className="save-message">You will save ${discount} on this order</p>}
                                <button className="btn-invest" onClick={handleNextStep}>Proceed</button>
                            </div>
                        </div>
                    )}

                    {step === 3 && (
                        <div className="payment-step">
                            <div className="payment-left">
                                <h2>Select Payment Method</h2>

                                <div className="payment-methods-box">
                                    <div className="payment-logos">
                                        {/* Placeholder logos - using text or basic shapes if images unavailable */}
                                        <span className="pay-logo paypal">PayPal</span>
                                        <span className="pay-logo gpay"><span className="g-blue">G</span> Pay</span>
                                        <span className="pay-logo apple"> Pay</span>
                                    </div>

                                    {/* <button className="btn-payment-invest" onClick={handlePayment}>Invest Now</button> */}
                                    <button className="btn-payment-card">Debit or Credit Card</button>
                                </div>
                            </div>

                            <div className="payment-divider"></div>

                            <div className="payment-right">
                                <div className="quote-summary-sidebar payment-summary-box">
                                    <h2 className="summary-title-large">Order Summary</h2>

                                    <div className="summary-row large-row">
                                        <span>{productTitle}</span>
                                        <span>${originalPrice ?? productPrice}</span>
                                    </div>
                                    {discount > 0 && (
                                        <div className="summary-row large-row">
                                            <span>Discount</span>
                                            <span>-${discount}</span>
                                        </div>
                                    )}
                                    <div className="summary-row large-row spacer-row">
                                        {/* Empty or just spacing */}
                                        <span></span>
                                        <span></span>
                                    </div>

                                    <div className="summary-total large-total">
                                        <span>Your Investment</span>
                                        <span>${productPrice}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                </div>

                {/* Navigation Buttons for Step 3 outside content box or inside? 
            Image shows Back and Continue buttons at the bottom, outside the blue cards.
        */}
                {step === 3 && (
                    <div className="step-navigation">
                        <button className="btn-nav-back" onClick={() => setStep(2)}>Back</button>
                        <button className="btn-nav-continue" onClick={handlePayment}>Continue</button>
                    </div>
                )}
            </div>

            {/* Terms Modal */}
            {showTerms && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h2>Terms and Conditions</h2>
                        </div>
                        <div className="modal-body" ref={modalBodyRef}>
                            <div className="term-item">
                                <h3>1. No Pause or Suspension</h3>
                                <p>Once a subscription is activated, it cannot be paused, stopped, or put on hold during the subscribed period. Services will remain active for the full duration of the plan.</p>
                            </div>
                            <div className="term-item">
                                <h3>2. No Plan Switching Mid-Cycle</h3>
                                <p>Customers cannot switch, downgrade, or upgrade between subscription plans during an active billing period. Any plan changes can be made only after the current cycle ends.</p>
                            </div>
                            <div className="term-item">
                                <h3>3. No Refund Policy</h3>
                                <p>Once payment is made and the subscription is activated, refunds will not be issued under any circumstances, whether partial or full.</p>
                            </div>
                            <div className="term-item">
                                <h3>4. Non-Transferable Subscription</h3>
                                <p>Subscriptions are non-transferable and can only be used by the registered customer or company account.</p>
                            </div>
                            <div className="term-item">
                                <h3>5. Job Usage Policy</h3>
                                <p>Each plan includes a defined number of jobs per cycle. Unused jobs will not roll over to the next billing period.</p>
                            </div>
                            <div className="term-item">
                                <h3>6. File Delivery and Quality</h3>
                                <p>Inkcredible Studios ensures all artwork files are delivered according to the plan specifications. Revision requests are limited or unlimited based on the chosen plan.</p>
                            </div>
                            <div className="term-item">
                                <h3>7. Artwork Complexity & Delivery Time</h3>
                                <p>Simple to medium-complexity artwork (requiring up to 3 hours of work) will be delivered within 24 hours. For complex files requiring more time, we will inform you in advance with the adjusted delivery timeline to ensure transparency and consistent quality.</p>
                            </div>
                            <div className="term-item">
                                <h3>8.Artwork Complexity & Delivery Time</h3>
                                <p>Simple to medium-complexity artwork (requiring up to 3 hours of work) will be delivered within 24 hours. For complex files requiring more time, we will inform you in advance with the adjusted delivery timeline to ensure transparency and consistent quality.</p>
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button className="btn-back" onClick={() => setShowTerms(false)}>Back</button>
                            <button className="btn-next" onClick={handleTermsAction}>{termsRead ? 'Continue' : 'Next'}</button>
                        </div>
                        {/* Scroll indicators or arrows if needed */}
                        <div className="scroll-indicator">
                            ▼
                        </div>
                    </div>
                </div>
            )}

            <Footer />
        </div>
    );
}

export default Quote;
