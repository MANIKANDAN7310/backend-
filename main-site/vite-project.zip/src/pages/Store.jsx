import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../App.css';
import './Store.css';
import Footer from '../components/Footer';
import LanguageSelector from '../components/LanguageSelector';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5001';

const FilterItem = ({ label, active, onClick }) => (
    <li className={`filter-item ${active ? 'active' : ''}`} onClick={onClick}>
        <span className="checkbox">{active ? '☑' : '☐'}</span> {label}
    </li>
);

function Store() {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('All');
    const navigate = useNavigate();

    // ── Fetch products from MongoDB ───────────────────────
    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const res = await fetch(`${API}/api/products`);
                const data = await res.json();
                if (data.success) {
                    setProducts(data.products);
                } else {
                    setError('Failed to load products');
                }
            } catch {
                setError('Cannot connect to server');
            } finally {
                setLoading(false);
            }
        };
        fetchProducts();
    }, []);

    const handleProductClick = (product) => {
        navigate('/quote', { state: { product } });
    };

    const filterGroups = [
        {
            title: 'Ornaments',
            items: ['Enamel Pin', 'Medals', 'Ornament Design', 'Keychain Design', 'Coins Design']
        },
        {
            title: 'Embroidery Design',
            items: ['Embroidery Design']
        },
    ];

    const handleFilterClick = (category) => {
        setSelectedCategory(category === selectedCategory ? 'All' : category);
    };

    const filteredProducts = selectedCategory === 'All'
        ? products
        : products.filter(p => p.category === selectedCategory);

    return (
        <div className="store-page">
            <header className="header">
                <div className="logo">
                    <Link to="/" style={{ textDecoration: 'none', color: 'inherit', display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <img src="/src/assets/logo.png" alt="Logo" width="50px" height="40px" />
                        Octoink Studio
                    </Link>
                </div>
                <nav>
                    <Link to="/#services">Services</Link>
                    <Link to="/#portfolio">Portfolio</Link>
                    <Link to="/#process">Process</Link>
                    <Link to="/#testimonials">Testimonials</Link>
                    <Link to="/store" className="active">Store</Link>
                    <Link to="/#contact" className="btn-quote-nav">Get a Quote</Link>
                    <LanguageSelector />
                </nav>
            </header>

            <div className="store-container">
                <aside className="store-sidebar">
                    <h2 className="section-label" style={{ marginBottom: '2rem' }}>Filters</h2>
                    {filterGroups.map((group, index) => (
                        <div key={index} className="filter-section">
                            <h3 className="filter-title">{group.title}</h3>
                            <ul className="filter-list">
                                {group.items.map(item => (
                                    <FilterItem
                                        key={item}
                                        label={item}
                                        active={selectedCategory === item}
                                        onClick={() => handleFilterClick(item)}
                                    />
                                ))}
                            </ul>
                        </div>
                    ))}
                </aside>

                <main className="store-content">
                    <div className="products-header">
                        <span className="product-count">{filteredProducts.length} Products</span>
                        <div className="sort-wrapper">
                            <select className="sort-select">
                                <option>Sort by: Featured</option>
                                <option>Price: Low to High</option>
                                <option>Price: High to Low</option>
                                <option>Newest</option>
                            </select>
                        </div>
                    </div>

                    {/* Loading */}
                    {loading && (
                        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-secondary)' }}>
                            <p>Loading products...</p>
                        </div>
                    )}

                    {/* Error */}
                    {error && (
                        <div style={{ textAlign: 'center', padding: '4rem', color: '#ef4444' }}>
                            <p>{error}</p>
                        </div>
                    )}

                    {/* No products */}
                    {!loading && !error && filteredProducts.length === 0 && (
                        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-secondary)' }}>
                            <p>No products found.</p>
                        </div>
                    )}

                    {/* Products Grid */}
                    {!loading && !error && filteredProducts.length > 0 && (
                        <div className="product-grid">
                            {filteredProducts.map(product => (
                                <div
                                    key={product._id}
                                    className="product-card"
                                    onClick={() => handleProductClick(product)}
                                    style={{ cursor: 'pointer' }}
                                >
                                    <img
                                        src={product.image ? `${API}/${product.image}` : 'https://placehold.co/300x300?text=No+Image'}
                                        alt={product.title}
                                        className="product-image"
                                    />
                                    <div className="product-info">
                                        <h3 className="product-title">{product.title}</h3>
                                        <p className="product-category">{product.category}</p>
                                        <div className="price-wrapper">
                                            <span className="product-price">${product.price}</span>
                                            {product.originalPrice && product.originalPrice > product.price && (
                                                <span className="original-price">${product.originalPrice}</span>
                                            )}
                                        </div>
                                        {/* Download button if file exists */}
                                        {product.file && (
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    // Increment download count
                                                    fetch(`${API}/api/products/${product._id}/download`, { method: 'PATCH' });
                                                    // Download the file
                                                    window.open(`${API}/${product.file}`, '_blank');
                                                }}
                                                style={{
                                                    marginTop: '0.75rem',
                                                    padding: '0.5rem 1.25rem',
                                                    background: 'var(--primary-color)',
                                                    color: 'white',
                                                    border: 'none',
                                                    borderRadius: '6px',
                                                    cursor: 'pointer',
                                                    fontSize: '0.85rem',
                                                    fontWeight: '600',
                                                    width: '100%',
                                                }}
                                            >
                                                ⬇ Download File
                                            </button>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </main>
            </div>

            <Footer />
        </div>
    );
}

export default Store;